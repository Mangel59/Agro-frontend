/**
 * @file PerfilCard.jsx
 * @module PerfilCard
 * @description Componente que representa una tarjeta con título, descripción e imagen.
 * @component
 */

import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';

/**
 * Componente PerfilCard.
 *
 * Representa una tarjeta visual que muestra una imagen, título y descripción.
 *
 * @function
 * @memberof module:PerfilCard
 * @param {Object} props - Props del componente.
 * @param {string} props.title - Título de la tarjeta.
 * @param {string} props.description - Descripción que aparece debajo del título.
 * @returns {JSX.Element} Componente visual de tarjeta.
 */
export default function PerfilCard({ title, description }) {
  return (
    <Card sx={{ maxWidth: 345, borderRadius: 2, boxShadow: 3 }}>
      <CardMedia
        sx={{ height: 140 }}
        image="static/image/cards/contemplative-reptile.jpg"
        title="green iguana"
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {title}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {description}
        </Typography>
      </CardContent>
    </Card>
  );
}
