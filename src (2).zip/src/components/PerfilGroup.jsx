/**
 * @file PerfilGroup.jsx
 * @module PerfilGroup
 * @description Componente que muestra tarjetas de navegación a los módulos de persona y empresa.
 * @component
 */

import React from "react";
import { Box, Card, CardContent, Typography, CardActions, Button } from "@mui/material";
import Persona from "../components/personas/Persona";
import Empresa from "../components/empresas/Empresa";


/**
 * Componente PerfilGroup.
 *
 * Muestra dos tarjetas con botones que permiten navegar a los módulos de gestión de personas y empresas.
 *
 * @function
 * @memberof module:PerfilGroup
 * @param {Object} props - Props del componente.
 * @param {Function} props.setCurrentModule - Función para cambiar el módulo visible en la interfaz.
 * @returns {JSX.Element} Elemento React que contiene las tarjetas de navegación.
 */
const PerfilGroup = ({ setCurrentModule }) => {
  return (
    <Box display="flex" flexWrap="wrap" justifyContent="center" p={2}>
      {/* Tarjeta para Personas */}
      <Card sx={{ minWidth: 275, m: 2 }}>
        <CardContent>
          <Typography variant="h5" component="div">
            Personas
          </Typography>
          <Typography sx={{ mb: 1.5 }} color="text.secondary">
            Gestión de personas - persona
          </Typography>
        </CardContent>
        <CardActions>
          <Button size="small" onClick={() => setCurrentModule(<Persona />)}>OPEN</Button>
        </CardActions>
      </Card>
      
      {/* Tarjeta para Empresas */}
      <Card sx={{ minWidth: 275, m: 2 }}>
        <CardContent>
          <Typography variant="h5" component="div">
            Empresas
          </Typography>
          <Typography sx={{ mb: 1.5 }} color="text.secondary">
            Gestión de empresas - empresa
          </Typography>
        </CardContent>
        <CardActions>
          <Button size="small" onClick={() => setCurrentModule(<Empresa />)}>OPEN</Button>
        </CardActions>
      </Card>
    </Box>
  );
};

export default PerfilGroup;
