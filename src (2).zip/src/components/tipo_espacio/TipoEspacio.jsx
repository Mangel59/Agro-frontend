/**
 * @file TipoEspacio.jsx
 * @module TipoEspacio
 * @description Componente principal para gestionar Tipos de Espacio: formulario, grilla, mensajes y recarga de datos.
 * @author Karla
 */

import * as React from "react";
import axios from "axios";
import MessageSnackBar from "../MessageSnackBar";
import FormTipoEspacio from "./FormTipoEspacio";
import GridTipoEspacio from "./GridTipoEspacio";
import { SiteProps } from "../dashboard/SiteProps";

/**
 * @typedef {Object} TipoEspacioRow
 * @property {number} id - ID del tipo de espacio
 * @property {string} nombre - Nombre del tipo de espacio
 * @property {string} descripcion - Descripción del tipo de espacio
 * @property {number} estado - Estado (1: Activo, 0: Inactivo)
 * @property {number|string} empresa - ID de la empresa asociada
 */

/**
 * @typedef {Object} SnackbarMessage
 * @property {boolean} open - Si el mensaje está visible
 * @property {string} severity - Nivel de severidad del mensaje (e.g. 'success', 'error')
 * @property {string} text - Texto del mensaje a mostrar
 */

/**
 * Componente principal para la gestión de Tipos de Espacio.
 *
 * @component
 * @returns {JSX.Element} Interfaz de administración para tipos de espacio.
 */
export default function TipoEspacio() {
  /** @type {TipoEspacioRow} */
  const row = {
    id: 0,
    nombre: "",
    descripcion: "",
    estado: 1,
    empresa: "",
  };

  /** @type {React.MutableRefObject<TipoEspacioRow>} */
  const [selectedRow, setSelectedRow] = React.useState(row);

  /** @type {React.MutableRefObject<SnackbarMessage>} */
  const [message, setMessage] = React.useState({
    open: false,
    severity: "success",
    text: "",
  });

  /** @type {boolean} */
  const [loading, setLoading] = React.useState(true);

  /** @type {string|null} */
  const [error, setError] = React.useState(null);

  /**
   * Función para cargar los datos desde la API.
   */
  const reloadData = React.useCallback(() => {
    setLoading(true);
    axios
      .get(`${SiteProps.urlbasev1}/tipo_espacio`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      })
      .then((response) => {
        const data = Array.isArray(response.data)
          ? response.data.map((item) => ({
              id: item.id,
              nombre: item.nombre,
              descripcion: item.descripcion,
              estado: item.estado,
            }))
          : [];

        console.log("Datos cargados:", data);
        setError(null);
      })
      .catch((error) => {
        const errorMessage = error.response?.data?.message || "Error desconocido.";
        setError(errorMessage);
        setMessage({
          open: true,
          severity: "error",
          text: errorMessage,
        });
      })
      .finally(() => {
        setLoading(false);
      });
  }, []);

  // Carga inicial de datos
  React.useEffect(() => {
    reloadData();
  }, [reloadData]);

  return (
    <div style={{ height: "100%", width: "100%" }}>
      <h1>Tipo Espacio</h1>
      <MessageSnackBar message={message} setMessage={setMessage} />
      {loading ? (
        <div style={{ textAlign: "center", margin: "20px" }}>Cargando datos...</div>
      ) : error ? (
        <div style={{ color: "red", textAlign: "center", margin: "20px" }}>{error}</div>
      ) : (
        <>
          <FormTipoEspacio
            setMessage={setMessage}
            selectedRow={selectedRow}
            setSelectedRow={setSelectedRow}
            reloadData={reloadData}
          />
          <GridTipoEspacio
            setSelectedRow={setSelectedRow}
            reloadData={reloadData}
          />
        </>
      )}
    </div>
  );
}
