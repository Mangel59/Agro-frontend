/**
 * @file GridTipoEspacio.jsx
 * @module GridTipoEspacio
 * @description Componente de grilla para mostrar los Tipos de Espacio con paginación y selección de fila.
 * @author Karla
 */

import React, { useEffect, useState } from "react";
import { DataGrid } from "@mui/x-data-grid";
import axios from "axios";
import { SiteProps } from "../dashboard/SiteProps";
import PropTypes from "prop-types";

/**
 * @typedef {Object} TipoEspacioRow
 * @property {number} id - ID del tipo de espacio
 * @property {string} nombre - Nombre del tipo de espacio
 * @property {string} descripcion - Descripción del tipo de espacio
 * @property {number} estado - Estado del tipo de espacio (1 = Activo, 0 = Inactivo)
 */

/**
 * @typedef {Object} GridTipoEspacioProps
 * @property {function} setSelectedRow - Función para establecer la fila seleccionada
 * @property {*} reloadData - Dependencia para volver a cargar datos cuando cambie
 */

/**
 * Componente de grilla que muestra los Tipos de Espacio desde el backend.
 *
 * @param {Object} props - Props del componente
 * @param {function} props.setSelectedRow - Función para seleccionar una fila
 * @param {*} props.reloadData - Dependencia para volver a cargar datos cuando cambie
 * @returns {JSX.Element} Componente de tabla
 */
export default function GridTipoEspacio({ setSelectedRow, reloadData }) {
  const [iespacios, setIespacios] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchIespacios = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`${SiteProps.urlbasev1}/tipo_espacio`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setIespacios(response.data || []);
        setError(null);
      } catch (error) {
        setError("No se pudieron cargar los tipos de espacio. Por favor, intente más tarde.");
        setIespacios([]);
      } finally {
        setLoading(false);
      }
    };

    fetchIespacios();
  }, [reloadData]);

  const columns = [
    { field: "id", headerName: "ID", width: 90 },
    { field: "nombre", headerName: "Nombre", width: 180 },
    { field: "descripcion", headerName: "Descripción", width: 250 },
    {
      field: "estado",
      headerName: "Estado",
      width: 120,
      valueGetter: (params) => (params.row.estado === 1 ? "Activo" : "Inactivo"),
    },
  ];

  /**
   * Maneja el evento de selección de una fila.
   * @param {*} params - Parámetros de fila seleccionada
   */
  const handleRowClick = (params) => {
    setSelectedRow(params.row);
  };

  if (loading) return <div>Cargando datos...</div>;
  if (error) return <div style={{ color: "red" }}>{error}</div>;

  return (
    <div style={{ height: 400, width: "100%" }}>
      <DataGrid
        rows={iespacios}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        onRowClick={handleRowClick}
        getRowId={(row) => row.id}
      />
    </div>
  );
}

GridTipoEspacio.propTypes = {
  setSelectedRow: PropTypes.func.isRequired,
  reloadData: PropTypes.any,
};
