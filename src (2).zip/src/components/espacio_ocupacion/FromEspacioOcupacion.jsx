/**
 * @file FromEspacioOcupacion.jsx
 * @module FromEspacioOcupacion
 * @description Componente para crear, actualizar y eliminar registros de ocupación de espacios.
 * @component
 */

import * as React from "react";
import PropTypes from "prop-types";
import AddIcon from "@mui/icons-material/Add";
import UpdateIcon from "@mui/icons-material/Update";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  Button,
  Box,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  InputLabel,
  MenuItem,
  FormControl,
  Select,
} from "@mui/material";
import axios from "axios";
import { SiteProps } from "../dashboard/SiteProps";

/**
 * Componente que permite agregar, actualizar o eliminar registros de ocupación de espacios.
 *
 * @param {Object} props - Propiedades del componente.
 * @param {Object} props.selectedRow - Fila seleccionada en la grilla.
 * @param {Function} props.setSelectedRow - Función para establecer la fila seleccionada.
 * @param {Function} props.setMessage - Función para mostrar mensajes de éxito o error.
 * @param {Function} props.reloadData - Función para recargar los datos después de un cambio.
 * @returns {JSX.Element} Formulario modal para CRUD de espacio ocupación.
 */
export default function FromEspacioOcupacion({ selectedRow = {}, setSelectedRow, setMessage, reloadData }) {
  const [open, setOpen] = React.useState(false);
  const [methodName, setMethodName] = React.useState("");
  const [sedes, setSedes] = React.useState([]);
  const [bloques, setBloques] = React.useState([]);
  const [espacios, setEspacios] = React.useState([]);
  const [actividades, setActividades] = React.useState([]);

  // Cargar sedes
  React.useEffect(() => {
    const fetchSedes = async () => {
      try {
        const response = await axios.get(`${SiteProps.urlbasev1}/sede/minimal`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setSedes(response.data || []);
      } catch (error) {
        console.error("Error al cargar sedes:", error);
        setMessage({ open: true, severity: "error", text: "Error al cargar las sedes." });
      }
    };
    fetchSedes();
  }, []);

  // Cargar bloques
  React.useEffect(() => {
    if (!selectedRow.sede) return;
    const fetchBloques = async () => {
      try {
        const response = await axios.get(`${SiteProps.urlbasev1}/bloque/minimal/sede/${selectedRow.sede}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setBloques(response.data || []);
      } catch (error) {
        console.error("Error al cargar bloques:", error);
        setMessage({ open: true, severity: "error", text: "Error al cargar los bloques." });
      }
    };
    fetchBloques();
  }, [selectedRow.sede]);

  // Cargar espacios
  React.useEffect(() => {
    if (!selectedRow.bloque) return;
    const fetchEspacios = async () => {
      try {
        const response = await axios.get(`${SiteProps.urlbasev1}/espacio/minimal/bloque/${selectedRow.bloque}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
        });
        setEspacios(response.data || []);
      } catch (error) {
        console.error("Error al cargar espacios:", error);
        setMessage({ open: true, severity: "error", text: "Error al cargar los espacios." });
      }
    };
    fetchEspacios();
  }, [selectedRow.bloque]);

  // Cargar actividades
  React.useEffect(() => {
    if (open) {
      const fetchActividades = async () => {
        try {
          const res = await axios.get(`${SiteProps.urlbasev1}/actividad_ocupacion/minimal`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          });
          setActividades(res.data || []);
        } catch (error) {
          console.error("Error al cargar actividades:", error);
          setMessage({ open: true, severity: "error", text: "Error al cargar actividades." });
        }
      };
      fetchActividades();
    }
  }, [open]);

  const formatDateTime = (date) => new Date(date).toISOString().slice(0, 19);

  const create = () => {
    setSelectedRow({ id: 0, espacio: "", actividadOcupacion: "", fechaInicio: "", fechaFin: "", estado: 1 });
    setMethodName("Add");
    setOpen(true);
  };

  const update = () => {
    if (!selectedRow || !selectedRow.id) {
      setMessage({ open: true, severity: "error", text: "Seleccione una fila para actualizar." });
      return;
    }
    setMethodName("Update");
    setOpen(true);
  };

  const deleteRow = () => {
    if (!selectedRow || !selectedRow.id) {
      setMessage({ open: true, severity: "error", text: "Seleccione una fila para eliminar." });
      return;
    }
    axios.delete(`${SiteProps.urlbasev1}/espacio_ocupacion/${selectedRow.id}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    }).then(() => {
      setMessage({ open: true, severity: "success", text: "Registro eliminado con éxito." });
      reloadData();
    }).catch((error) => {
      console.error("Error al eliminar:", error);
      setMessage({ open: true, severity: "error", text: "Error al eliminar el registro." });
    });
  };

  const handleClose = () => setOpen(false);

  const handleSubmit = () => {
    const payload = {
      id: selectedRow.id || null,
      espacio: selectedRow.espacio,
      actividadOcupacion: selectedRow.actividadOcupacion,
      fechaInicio: formatDateTime(selectedRow.fechaInicio),
      fechaFin: formatDateTime(selectedRow.fechaFin),
      estado: selectedRow.estado,
    };

    const method = methodName === "Add" ? axios.post : axios.put;
    const url = `${SiteProps.urlbasev1}/espacio_ocupacion${methodName === "Add" ? "" : `/${selectedRow.id}`}`;

    method(url, payload, {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    }).then(() => {
      setMessage({
        open: true,
        severity: "success",
        text: methodName === "Add" ? "Registro creado con éxito." : "Registro actualizado con éxito.",
      });
      reloadData();
      handleClose();
    }).catch((error) => {
      console.error("Error al guardar:", error);
      setMessage({ open: true, severity: "error", text: "Error al guardar el registro." });
    });
  };

  return (
    <>
      <Box display="flex" justifyContent="flex-end" mb={2}>
        <Button variant="outlined" color="primary" startIcon={<AddIcon />} onClick={create}>Agregar</Button>
        <Button variant="outlined" color="primary" startIcon={<UpdateIcon />} onClick={update} style={{ marginLeft: 10 }}>Actualizar</Button>
        <Button variant="outlined" color="secondary" startIcon={<DeleteIcon />} onClick={deleteRow} style={{ marginLeft: 10 }}>Eliminar</Button>
      </Box>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{methodName === "Add" ? "Agregar Registro" : "Actualizar Registro"}</DialogTitle>
        <DialogContent>
          <TextField label="Fecha Inicio" type="datetime-local" fullWidth margin="normal"
            value={selectedRow.fechaInicio || ""} onChange={(e) => setSelectedRow((prev) => ({ ...prev, fechaInicio: e.target.value }))} />
          <TextField label="Fecha Fin" type="datetime-local" fullWidth margin="normal"
            value={selectedRow.fechaFin || ""} onChange={(e) => setSelectedRow((prev) => ({ ...prev, fechaFin: e.target.value }))} />
          <FormControl fullWidth margin="normal">
            <InputLabel>Actividad</InputLabel>
            <Select
              value={selectedRow.actividadOcupacion || ""}
              onChange={(e) => setSelectedRow((prev) => ({ ...prev, actividadOcupacion: e.target.value }))}
            >
              {actividades.map((a) => (
                <MenuItem key={a.id} value={a.id}>{a.nombre}</MenuItem>
              ))}
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">Cancelar</Button>
          <Button onClick={handleSubmit} color="primary">{methodName === "Add" ? "Agregar" : "Actualizar"}</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

// Validación de props
FromEspacioOcupacion.propTypes = {
  selectedRow: PropTypes.object.isRequired,
  setSelectedRow: PropTypes.func.isRequired,
  setMessage: PropTypes.func.isRequired,
  reloadData: PropTypes.func.isRequired,
};
