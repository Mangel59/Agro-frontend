/**
 * @file EspacioOcupacion.jsx
 * @module EspacioOcupacion
 * @description Componente principal que integra la gestión de espacio ocupación.
 * @component
 */

import React, { useState } from "react";
import FromEspacioOcupacion from "./FromEspacioOcupacion";
import GridEspacioOcupacion from "./GridEspacioOcupacion";

/**
 * Componente EspacioOcupacion.
 * Muestra un formulario y una grilla para gestionar registros de ocupación de espacios.
 *
 * @returns {JSX.Element} Componente visual con formulario y tabla de espacio ocupación.
 */
export default function EspacioOcupacion() {
  const [selectedRow, setSelectedRow] = useState(null);
  const [selectedEspacio, setSelectedEspacio] = useState(1);
  const [reloadFlag, setReloadFlag] = useState(false);
  const [message, setMessage] = useState({ open: false, severity: "", text: "" });

  const reloadData = () => {
    setReloadFlag((prev) => !prev);
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Gestión de Ocupación de Espacios</h2>
      <FromEspacioOcupacion
        selectedRow={selectedRow}
        setSelectedRow={setSelectedRow}
        setMessage={setMessage}
        reloadData={reloadData}
      />
      <GridEspacioOcupacion
        selectedEspacio={selectedEspacio}
        setSelectedRow={setSelectedRow}
        reloadFlag={reloadFlag}
      />
    </div>
  );
}
