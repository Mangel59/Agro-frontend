/**
 * @file FormSede.jsx
 * @module FormSede
 * @description Formulario de gestión de sedes: permite agregar, actualizar y eliminar sedes. Incluye manejo de municipios, grupos y tipos de sede desde la API.
 * @author Karla
 */

import * as React from "react";
import axios from "axios";
import {
  Button,
  Box,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import { SiteProps } from "../dashboard/SiteProps";
import AddIcon from "@mui/icons-material/Add";
import UpdateIcon from "@mui/icons-material/Update";
import DeleteIcon from "@mui/icons-material/Delete";

/**
 * @typedef {Object} SedeRow
 * @property {number} id
 * @property {string|number} grupo
 * @property {string|number} tipoSede
 * @property {string} nombre
 * @property {string|number} municipio
 * @property {string|null} geolocalizacion
 * @property {number} area
 * @property {string} comuna
 * @property {string} descripcion
 * @property {number} estado
 */

/**
 * @typedef {Object} SnackbarMessage
 * @property {boolean} open
 * @property {string} severity
 * @property {string} text
 */

/**
 * @typedef {Object} FormSedeProps
 * @property {SedeRow} selectedRow - Fila seleccionada para edición
 * @property {Function} setSelectedRow - Función para establecer la fila seleccionada
 * @property {Function} reloadData - Función para recargar los datos
 * @property {Function} setMessage - Función para mostrar mensajes tipo snackbar
 */

/**
 * Componente FormSede.
 *
 * @param {FormSedeProps} props - Props del componente
 * @returns {JSX.Element}
 */
export default function FormSede(props) {
  const [open, setOpen] = React.useState(false);
  const [methodName, setMethodName] = React.useState("");
  const [municipios, setMunicipios] = React.useState([]);
  const [grupos, setGrupos] = React.useState([]);
  const [tipoSedes, setTipoSedes] = React.useState([]);

  const selectedRow = props.selectedRow || {};

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const [municipioRes, grupoRes, tipoSedeRes] = await Promise.all([
          axios.get(`${SiteProps.urlbasev1}/items/municipio`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          }),
          axios.get(`${SiteProps.urlbasev1}/grupo/minimal`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          }),
          axios.get(`${SiteProps.urlbasev1}/tipo_sede/minimal`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          }),
        ]);
        setMunicipios(municipioRes.data || []);
        setGrupos(grupoRes.data || []);
        setTipoSedes(tipoSedeRes.data || []);
      } catch (error) {
        console.error("Error al cargar datos iniciales:", error);
        props.setMessage({
          open: true,
          severity: "error",
          text: "Error al cargar datos iniciales.",
        });
      }
    };

    fetchData();
  }, []);

  const create = () => {
    const emptyRow = {
      id: 0,
      grupo: "",
      tipoSede: "",
      nombre: "",
      municipio: "",
      geolocalizacion: null,
      area: 0,
      comuna: "",
      descripcion: "",
      estado: 1,
    };
    props.setSelectedRow(emptyRow);
    setMethodName("Add");
    setOpen(true);
  };

  const update = () => {
    if (!selectedRow || selectedRow.id === 0) {
      props.setMessage({
        open: true,
        severity: "error",
        text: "Seleccione una fila para actualizar.",
      });
      return;
    }
    setMethodName("Update");
    setOpen(true);
  };

  const deleteRow = () => {
    if (!selectedRow || selectedRow.id === 0) {
      props.setMessage({
        open: true,
        severity: "error",
        text: "Seleccione una fila para eliminar.",
      });
      return;
    }

    axios
      .delete(`${SiteProps.urlbasev1}/sede/${selectedRow.id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      })
      .then(() => {
        props.setMessage({
          open: true,
          severity: "success",
          text: "Sede eliminada con éxito.",
        });
        props.reloadData();
      })
      .catch((error) => {
        console.error("Error al eliminar sede:", error);
        props.setMessage({
          open: true,
          severity: "error",
          text: "Error al eliminar la sede. Intente nuevamente.",
        });
      });
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSubmit = () => {
    const payload = {
      id: selectedRow.id || null,
      grupo: selectedRow.grupo,
      tipoSede: selectedRow.tipoSede,
      nombre: selectedRow.nombre,
      municipio: selectedRow.municipio,
      geolocalizacion: selectedRow.geolocalizacion || null,
      area: selectedRow.area,
      comuna: selectedRow.comuna,
      descripcion: selectedRow.descripcion,
      estado: selectedRow.estado,
    };

    const url = `${SiteProps.urlbasev1}/sede`;
    const method = methodName === "Add" ? axios.post : axios.put;
    const endpoint = methodName === "Add" ? url : `${url}/${selectedRow.id}`;

    method(endpoint, payload, {
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    })
      .then(() => {
        props.setMessage({
          open: true,
          severity: "success",
          text: methodName === "Add" ? "Sede creada con éxito." : "Sede actualizada con éxito.",
        });
        props.reloadData();
        handleClose();
      })
      .catch((error) => {
        console.error("Error al enviar datos:", error);
        props.setMessage({
          open: true,
          severity: "error",
          text: "Error al enviar datos. Intente nuevamente.",
        });
      });
  };

  return (
    <React.Fragment>
      <Box display="flex" justifyContent="right" mb={2}>
        <Button variant="outlined" color="primary" startIcon={<AddIcon />} onClick={create} style={{ marginRight: "10px" }}>
          ADD
        </Button>
        <Button variant="outlined" color="primary" startIcon={<UpdateIcon />} onClick={update} style={{ marginRight: "10px" }}>
          UPDATE
        </Button>
        <Button variant="outlined" color="primary" startIcon={<DeleteIcon />} onClick={deleteRow}>
          DELETE
        </Button>
      </Box>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{methodName === "Add" ? "Agregar Sede" : "Actualizar Sede"}</DialogTitle>
        <DialogContent>
          <FormControl fullWidth margin="normal">
            <InputLabel>Grupo</InputLabel>
            <Select
              value={selectedRow.grupo || ""}
              onChange={(e) => props.setSelectedRow({ ...selectedRow, grupo: e.target.value })}
            >
              {grupos.map((grupo) => (
                <MenuItem key={grupo.id} value={grupo.id}>
                  {grupo.nombre}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <FormControl fullWidth margin="normal">
            <InputLabel>Tipo de Sede</InputLabel>
            <Select
              value={selectedRow.tipoSede || ""}
              onChange={(e) => props.setSelectedRow({ ...selectedRow, tipoSede: e.target.value })}
            >
              {tipoSedes.map((tipo) => (
                <MenuItem key={tipo.id} value={tipo.id}>
                  {tipo.nombre}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label="Nombre"
            value={selectedRow.nombre || ""}
            onChange={(e) => props.setSelectedRow({ ...selectedRow, nombre: e.target.value })}
            required
          />

          <FormControl fullWidth margin="normal">
            <InputLabel>Municipio</InputLabel>
            <Select
              value={selectedRow.municipio || ""}
              onChange={(e) => props.setSelectedRow({ ...selectedRow, municipio: e.target.value })}
            >
              {municipios.map((mun) => (
                <MenuItem key={mun.id} value={mun.id}>
                  {`${mun.id} - ${mun.nombre}`}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label="Área"
            value={selectedRow.area || ""}
            onChange={(e) => props.setSelectedRow({ ...selectedRow, area: e.target.value })}
          />

          <TextField
            fullWidth
            label="Comuna"
            value={selectedRow.comuna || ""}
            onChange={(e) => props.setSelectedRow({ ...selectedRow, comuna: e.target.value })}
          />

          <TextField
            fullWidth
            label="Descripción"
            value={selectedRow.descripcion || ""}
            onChange={(e) => props.setSelectedRow({ ...selectedRow, descripcion: e.target.value })}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancelar
          </Button>
          <Button onClick={handleSubmit} color="primary">
            {methodName === "Add" ? "Agregar" : "Actualizar"}
          </Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}
