import React, { useState, useEffect } from "react";
import axios from "axios";
import { DataGrid } from "@mui/x-data-grid";
import { Box, CircularProgress, Typography } from "@mui/material";
import { SiteProps } from "../dashboard/SiteProps";

export default function GridProduccion({ espacioId }) {
  const [producciones, setProducciones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!espacioId) return;

    const token = localStorage.getItem("token");
    if (!token) {
      setError("No se encontró el token de autenticación.");
      return;
    }

    setLoading(true);
    setError(null);

    axios
      .get(`${SiteProps.urlbasev1}/producciones/${espacioId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        setProducciones(response.data.content); // Usa el array dentro de "content"
      })
      .catch((error) => {
        console.error("Error al cargar producciones:", error);
        setError("Error al cargar las producciones. Por favor, verifica tu conexión o permisos.");
      })
      .finally(() => {
        setLoading(false);
      });
  }, [espacioId]);

  const columns = [
    { field: "id", headerName: "ID", width: 90 },
    { field: "nombre", headerName: "Nombre", width: 150 },
    { field: "descripcion", headerName: "Descripción", width: 250 },
    { field: "tipoProduccion", headerName: "Tipo Producción", width: 150 },
    { field: "espacio", headerName: "Espacio", width: 100 },
    { field: "estado", headerName: "Estado", width: 120 },
  ];

  if (!espacioId) {
    return <Typography>Selecciona un espacio para ver las producciones.</Typography>;
  }

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="200px">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <Typography color="error">{error}</Typography>;
  }

  if (producciones.length === 0) {
    return <Typography>No hay producciones disponibles para este espacio.</Typography>;
  }

  return (
    <Box sx={{ height: 400, width: "100%" }}>
      <DataGrid
        rows={producciones}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5, 10, 20]}
        getRowId={(row) => row.id} // Asegura que 'id' sea único
        disableSelectionOnClick
      />
    </Box>
  );
}
