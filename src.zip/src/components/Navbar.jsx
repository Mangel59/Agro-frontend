import React, { useEffect, useState } from "react";
import "./navbar.css";
import { useThemeToggle } from "../dashboard/ThemeToggleProvider";

export default function Navbar({
  isAuthenticated,
  onLogin,
  onRegister,
  onLogout,
}) {
  const { toggleTheme } = useThemeToggle();
  const [opened, setOpened] = useState(false);
  const [transparent, setTransparent] = useState(true);

  // Hace el header “sólido” cuando scrolleas
  useEffect(() => {
    const onScroll = () => setTransparent(window.scrollY <= 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <section
      className={`navbar-wrapper is-sticky ${transparent ? "is-transparent" : ""}`}
    >
      <nav
        className={`navbar navbar-dropdown navbar-expand-lg ${opened ? "opened" : ""}`}
      >
        <div className="menu_box container-fluid">
          {/* BRAND */}
          <div className="navbar-brand d-flex">
            <span className="navbar-logo">
              <a href="#">
                <img src="/logo.png" alt="logo" />
              </a>
            </span>

            <span className="navbar-caption-wrap">
              <a className="navbar-caption" href="#">Agro Application</a>
            </span>

            {/* TOGGLER (mobile) */}
            <button
              className="navbar-toggler"
              aria-label="Toggle navigation"
              onClick={() => setOpened(o => !o)}
            >
              <div className="hamburger">
                <span></span><span></span><span></span><span></span>
              </div>
            </button>
          </div>

          {/* NAV LINKS + CTAs + ICONOS */}
          <div className="navbar-collapse" id="navbarSupportedContent">
            <div className="navigation-wrapper">
              <ul className="navbar-nav nav-dropdown">
                <li className="nav-item">
                  <a className="nav-link link" href="#inicio">Inicio</a>
                </li>

                <li className="nav-item dropdown">
                  <a className="nav-link link" href="#funciones">Funciones</a>
                  <div className="dropdown-menu">
                    <a className="dropdown-item" href="#inventario">Inventario</a>
                    <div className="dropdown-submenu">
                      <a className="dropdown-item" href="#reportes">Reportes ▸</a>
                      <div className="dropdown-menu">
                        <a className="dropdown-item" href="#ventas">Ventas</a>
                        <a className="dropdown-item" href="#compras">Compras</a>
                      </div>
                    </div>
                  </div>
                </li>

                <li className="nav-item">
                  <a className="nav-link link" href="#precios">Precios</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link link" href="#contacto">Contacto</a>
                </li>
              </ul>
            </div>

            <div className="mbr-section-btn-main">
              {!isAuthenticated ? (
                <>
                  <button className="btn btn-primary" onClick={onLogin}>Login</button>
                  <button className="btn btn-primary" onClick={onRegister}>Register</button>
                </>
              ) : (
                <button className="btn btn-primary" onClick={onLogout}>Cerrar sesión</button>
              )}
            </div>

            <div className="icons-menu-main">
              <button className="iconfont-wrapper" onClick={toggleTheme} title="Cambiar tema">
                🌓
              </button>
            </div>
          </div>
        </div>
      </nav>
    </section>
  );
}
